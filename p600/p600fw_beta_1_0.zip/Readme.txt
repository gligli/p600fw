**********
* P600FW *
**********

https://github.com/gligli/p600fw (Project page)

http://forum.anafrog.com/phpBB/viewtopic.php?f=36&t=10535 (French forum)

Description
===========

This is the P600FW project, a CPU/firmware remake for the SCI Prophet 600.
It uses a slightly modified Teensy++ board (http://www.pjrc.com/store/teensypp_pins.html) that plugs into the Z80 socket.

Modifying the Teensy++
======================

See documentation PDFs...

Usage
=====

See documentation PDFs...

History
=======

- alpha 20130226 : First public version.
- beta 1.0: First proper release.